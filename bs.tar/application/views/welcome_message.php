<?php $this->load->view('header.php'); ?>
<div class="main">
	<span class="shadow-top">
		<?php // $_SERVER['REQUEST_URI'] ?>  
		</span>
				<!-- shell -->
	<div class="shell">
		<div class="container">
			
					<div class="widget">
						<h1><?php echo $header;?></h1>
						<p><br></p>
						<p>This website is created for mobile enthusiasts that have interest in time management for service operations. 
                                                </p>
						
						<p>Enjoy your visit.</p>
						
						
			 		</div>
         </div>			
       </div>
   </div>  

   <?php $this->load->view('footer.php'); ?>
