<?php $this->load->view('header.php'); ?>
 <div class="main">
	<span class="shadow-top">
		<?php // $_SERVER['REQUEST_URI'] ?>  
		</span>
				<!-- shell -->
	<div class="shell">
		<div class="container">
			
					
						<h3><?php echo "Log In";?></h3>
  
					   <?php echo validation_errors(); ?>
					   <?php echo form_open('verifylogin'); ?>
					
					                <p> <!--
					                    <label for="username" class="uname" > Your username </label><br>
					                    <input id="username" name="username" required="required" type="text" placeholder="myusername"/>
					                -->
                                                        <label for="username" class="username"  >Korisnik  </label><br>
                                                        <select name="username">
                                                            <option value="">Izaberi</option>
                                                            <?php foreach($users as $user):?>
                                                            <option value="<?=$user['id_korisnik'];?>" ><?=$user['username'];?>   </option>
                                                            <?php endforeach;?>
                                                        </select>
                                                        </p>
					                <p>
					                    <label for="password" class="youpasswd" > Your password </label><br>
					                    <input id="password" name="password" required="required" type="password" placeholder="eg. MyP@ssw0rd" />
					                </p>
					               
					               
					                <p class="login button">
					                    <input type="submit" value="Login" />
					                </p>
					          
					         
					   </form>
					   <br><br><br>
         			
         </div>			
       </div>
   </div>  
   <?php $this->load->view('footer.php'); ?>