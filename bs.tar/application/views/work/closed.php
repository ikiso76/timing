<?php $this->load->view('header.php'); ?>
 <div class="main">
	<span class="shadow-top">
		<?php // $_SERVER['REQUEST_URI'] ?>  
		</span>
				<!-- shell -->
	<div class="shell">
		<div class="container">
			
					<div class="widget">
						<h3><?php echo $header;?></h3>
                                            <?php     if ($reply!="") 
                                              echo '<h4>'.$reply.'</h4>';
                                          else
                                              echo ''; ?>
                                                <ul>
				   		<?php  
						if (isset($works)){  
			   			foreach($works as $work):
					   		
                                                        if ($work['id_status_servis']!=2)
							{
								$workLink= '<a href='.base_url().'work/del_work_action/?id='.$work['id_servis'] .'>Obnovi</a>';
							} else {
								$workLink= '<a href='.base_url().'work/finish_work_action/?id='.$work['id_nalog'] .'&uid='.$work['id_korisnik'] .'>Zatvori</a> ';
							}
					                if ($canDel!=0)
							{
								$deLink= '<a href=/work/del_work/?id='.$work['id_dokument'] .'>Ukloni</a>';
							} else {
								$deLink= ' ';
							}
							?>
							<li>
							<p><?php echo 'Name: '.$work['broj_dokumenta'].'  <span>'.$workLink.'</span></a>'.'  <span>'.$deLink.'</span></a>';?>  </p>
							</li>
                                                
					        <?php endforeach;?>
                                                </ul>
					  
		    			<?php }?>
			 		</div>
         </div>			
       </div>
   </div>  
   <?php $this->load->view('footer.php'); ?>