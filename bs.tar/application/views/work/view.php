<?php $this->load->view('header.php'); ?>
 <div class="main">
	<span class="shadow-top">
		<?php // $_SERVER['REQUEST_URI'] ?>  
		</span>
				<!-- shell -->
	<div class="shell">
		<div class="container">
			
					<div class="widget">
						<h3><?php echo $header;?></h3>
						
						
							
			 		</div>
         </div>			
       </div>
   </div>  
   <?php $this->load->view('footer.php'); ?>