</div>
<div  id="footer">
	<span class="shadow-bottom"></span>
	<div class="footer-bottom">
		<div class="shell">
			<nav class="footer-nav">
				<ul>
				<?php foreach($menu as $m):
						
					?>
					
					<?php //echo '<a href='.$m['link'].' class='.$klasa.'>'.$m['name'].'</a>';
							echo ' <li ><a href='.$m['link'].'>'.$m['name'].'</a></li>';
					?>
					
				<?php endforeach;?>
				</ul>
				<div class="cl">&nbsp;</div>
			</nav>
		<p class="copy"><?php //echo $username. ' | My settings (to do)' ?></p>
		</div>
	</div>
</div>
<!-- end of footer -->
</body>
</html>