<?php $this->load->view('header.php'); ?>
 <div class="main">
	<span class="shadow-top">
		<?php // $_SERVER['REQUEST_URI'] ?>  
		</span>
				<!-- shell -->
	<div class="shell">
		<div class="container">
			
					<div class="widget"> 
					
					  <?php echo '<h4>'. $name.'</h4>';//.$grupaid;//.$admin; 
                                          if ($reply!="") 
                                              echo '<h4>'.$reply.'</h4>';
                                          else
                                              echo '';
                                          ?>
                                                        
						<h3><?php echo $header;?></h3>
						<?php echo form_open('/work/'); ?>
						<?php 
						
						if (count($MyOrder)>1){
                                                   
                                                      echo '<select name="RadniNalog" onchange="submit()">
                                                            <option value="">Radni Nalog</option>';
                                                             foreach($MyOrder as $order):
                                                                 if (( $order['id_status_servis']==1 && $userid!=$order['id_korisnik'] ) || ($order['id_status_servis']==3 )){
                                                                     if ( $admin!="1")
                                                                        continue; 
                                                                 }
                                                                    if (($order['id_dokument'] == $thisOrder['id_dokument']))
                                                                        $sel = 'selected="selected"';
                                                                    else 
                                                                        $sel = '';
                                                                    echo '<option value="'.$order['id_dokument'].'" '.$sel.' >'.$order['broj_dokumenta'].'</option>';
                                                           endforeach;  
                                                        echo '</select>';
                                                        echo'<p> </p>';
                                                        
                                                        if ((!empty($orderStatus['id_status_servis']) && $orderStatus['id_status_servis']==1)|| $thisOrder['id_dokument']==0) {
                                                            echo '<p class="login button"><input name="Action" value="" /><h4>';
                                                            
                                                            if ($thisOrder['id_dokument']==0) 
                                                                 echo ''.'</h4></p>';
                                                            else
                                                                echo ' Zapoceto: '.$orderStatus['updated'].'</h4></p>';
                                                        }
                                                        else 
                                                            echo'<p class="login button"><input type="submit" name="Action" value="Start" /></p>';
                                                        
                                                        if (!empty($orderStatus['id_status_servis']) && $orderStatus['id_status_servis']==1)    
                                                              echo'<p class="login button"><input type="submit" name="Action2" value="Stop" /></p>';
                                                        else 
                                                            echo'<p class="login button"><input  name="Action2" value="" /><h4>';
                                                        if (!empty($orderStatus['updated']) && $orderStatus['id_status_servis']==2) 
                                                            echo ' Zavrseno: '.$orderStatus['updated'].'</h4></p>';                                                            
                                                        else
                                                           echo ''.'</h4></p>'; 
                                                        
                                                        if (!empty($orderStatus['id_status_servis']) && $orderStatus['id_status_servis']==2)    
                                                              echo'<p class="login button"><input type="submit" name="Action3" value="Kraj" /></p>';
                                                        else 
                                                           echo'<p class="login button"><input onclick="this.disabled=true";" name="Action3" value="" /></p>';
                                                  
						}else {
							echo 'NO services';
							}
                                                echo '</form>';
						?>

			 		</div>
         </div>			
       </div>
   </div>  
</div> 
   <?php $this->load->view('footer.php'); ?>
