<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=0" />
<title><?php  echo $title; ?></title>
	<link rel="shortcut icon" type="image/icon" href="favicon.ico" />
	<link rel="icon" href="<?=base_url()?>/favicon.ico" type="image/icon">
	
	<link rel="stylesheet" href="<?=base_url()?>/css/style.css" type="text/css" media="all" />
	<link rel="stylesheet" href="<?=base_url()?>/css/flexslider.css" type="text/css" media="all" />
	<link href='http://fonts.googleapis.com/css?family=Ubuntu:400,500,700' rel='stylesheet' type='text/css' />
	
	<script src="<?=base_url()?>/js/jquery-1.8.0.min.js" type="text/javascript"></script>
	<!--[if lt IE 9]>
		<script src="/js/modernizr.custom.js"></script>
	<![endif]-->
	<script src="<?=base_url()?>/js/jquery.flexslider-min.js" type="text/javascript"></script>
	<script src="<?=base_url()?>/js/functions.js" type="text/javascript"></script>
</head>

 <body>
 <div id="wrapper">
		
		<!-- top-nav -->
		<nav class="top-nav">
			<div class="shell">
			<a href="#" class="nav-btn"><?php  //echo $title; ?>Homepage<span></span></a>
				<span class="top-nav-shadow"></span>
				<ul>
				<?php foreach($menu as $m):
					if ($_SERVER['REQUEST_URI']==$m['link']) {
						$klasa='active';
					} else {
						$klasa='';
					}	
					?>
					
					<?php //echo '<a href='.$m['link'].' class='.$klasa.'>'.$m['name'].'</a>';
							echo ' <li class='.$klasa.'><span><a href='.$m['link'].'>'.$m['name'].'</a></span></li>';
					?>
					
				<?php endforeach;?>
				</ul>
			</div>
		</nav>